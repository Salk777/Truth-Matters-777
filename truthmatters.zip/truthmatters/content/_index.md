---
title: "Truth Matters"
featured_image: '/images/Agartha-2.JPG'
description: "The truth may hurt for a litte while...but a lie hurts forever"
---
Welcome to Truth Matters....truth investigations of all forms.
